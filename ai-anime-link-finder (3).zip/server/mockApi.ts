import { MockTransaction } from '../types';

// This is our "database" of successful, unclaimed transactions.
// In a real app, this data would come from Payeer's IPN/webhook service to your backend.
const mockTransactionDatabase: MockTransaction[] = [
    { transactionId: 'TX12345ABC', amount: 0.50, userIdentifier: 'testuser', claimed: false },
    { transactionId: 'TX67890DEF', amount: 1.00, userIdentifier: 'janedoe', claimed: false },
    { transactionId: 'TX55555XYZ', amount: 3.00, userIdentifier: 'testuser', claimed: false },
    { transactionId: 'TX98765PQR', amount: 0.50, userIdentifier: 'another_user', claimed: false },
    { transactionId: 'TX77777JKL', amount: 3.00, userIdentifier: 'admin', claimed: false },
    { transactionId: '2225172628', amount: 1.00, userIdentifier: 'david joe', claimed: false },
    { transactionId: '2224661788', amount: 1.00, userIdentifier: 'mike_t', claimed: false },
];

/**
 * Simulates finding a transaction in the database without full verification.
 */
export const findTransaction = async (transactionId: string): Promise<MockTransaction | null> => {
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate search delay
    const transaction = mockTransactionDatabase.find(
        tx => tx.transactionId.toLowerCase() === transactionId.toLowerCase().trim()
    );
    return transaction || null;
}

/**
 * Simulates calling a backend to verify a Payeer transaction.
 */
export const verifyPayeerTransaction = async (
    transactionId: string,
    userIdentifier: string,
    expectedAmount: number
): Promise<{ success: boolean; message: string }> => {
    
    // Simulate network delay for realism
    await new Promise(resolve => setTimeout(resolve, 1500));

    const transaction = mockTransactionDatabase.find(
        tx => tx.transactionId.toLowerCase() === transactionId.toLowerCase().trim()
    );

    if (!transaction) {
        return { success: false, message: 'Transaction ID not found. Please check the ID and try again.' };
    }

    if (transaction.claimed) {
        return { success: false, message: 'This Transaction ID has already been claimed.' };
    }
    
    // In a real scenario, you might have more flexible validation.
    // Here we'll do a strict check for demonstration.
    if (transaction.userIdentifier.toLowerCase() !== userIdentifier.toLowerCase()) {
        return { success: false, message: `This transaction was for a different user (${transaction.userIdentifier}). Please ensure you used your username '${userIdentifier}' in the memo.` };
    }

    if (transaction.amount !== expectedAmount) {
        return { success: false, message: `The payment amount is incorrect. We expected $${expectedAmount.toFixed(2)} but the transaction was for $${transaction.amount.toFixed(2)}.` };
    }

    // Mark as claimed to prevent reuse in this session.
    transaction.claimed = true;
    
    return { success: true, message: 'Payment verified successfully!' };
};

/**
 * Helper to get examples for the UI, so the user knows what to enter.
 */
export const getValidTransactionExamples = (): MockTransaction[] => {
    // Return a copy to prevent direct mutation from the UI
    return JSON.parse(JSON.stringify(mockTransactionDatabase));
};
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { GeminiResponse } from '../types';
import { KNOWLEDGE_BASE } from '../knowledge';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    responseText: {
      type: Type.STRING,
      description: "A friendly, conversational response to the user. If the query is ambiguous, ask for clarification. If nothing is found, say so politely. If links are found, introduce them."
    },
    foundLinks: {
      type: Type.ARRAY,
      description: "A list of links found in the knowledge base that directly match the user's query.",
      items: {
        type: Type.OBJECT,
        properties: {
          text: {
            type: Type.STRING,
            description: "The full line of text for the found episode link from the knowledge base."
          },
          url: {
            type: Type.STRING,
            description: "The corresponding URL for the episode."
          }
        },
        required: ["text", "url"]
      }
    }
  },
  required: ["responseText", "foundLinks"]
};

export const findAnimeLinks = async (query: string, chatHistory: string): Promise<GeminiResponse> => {
    const systemInstruction = `
        You are an AI assistant helping a user find anime episode links from a provided knowledge base.
        Your knowledge is STRICTLY limited to the text provided in the knowledge base. Do not make up information or links.

        Your task:
        1. Analyze the user's request, considering the previous chat history for context.
        2. Search the knowledge base for matching anime titles and episode numbers.
        3. If the user's request is ambiguous or too general (e.g., "the latest episode", "an action anime"), you MUST ask clarifying questions to understand their need (e.g., "Which anime are you referring to?", "Could you be more specific?").
        4. If multiple versions of an episode are found (e.g., sub, dub, different resolutions), present all of them.
        5. If the requested anime or episode is explicitly listed as "coming soon" or unavailable, state that clearly.
        6. If nothing is found, politely inform the user that you couldn't find it in your knowledge base.
        7. Structure your findings into the requested JSON format. The 'responseText' should be your conversational message to the user, and 'foundLinks' should contain the data.
    `;

    const prompt = `
      KNOWLEDGE BASE:
      ---
      ${KNOWLEDGE_BASE}
      ---
      
      CHAT HISTORY:
      ---
      ${chatHistory}
      ---

      USER'S LATEST REQUEST: "${query}"

      Based on the user's latest request and the chat history, please analyze the knowledge base and provide a response in the required JSON format.
    `;

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            systemInstruction: systemInstruction,
            responseMimeType: "application/json",
            responseSchema: responseSchema,
        },
    });

    try {
        const jsonText = response.text.trim();
        const data = JSON.parse(jsonText);
        return data as GeminiResponse;
    } catch (e) {
        console.error("Failed to parse Gemini response as JSON:", e);
        console.error("Raw response text:", response.text);
        throw new Error("The AI returned an unexpected response format. Please try rephrasing your request.");
    }
};

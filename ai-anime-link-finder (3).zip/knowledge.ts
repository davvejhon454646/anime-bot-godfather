export const KNOWLEDGE_BASE = `
anime + episode number : episode link

Goukon ni Ittara Onna ga Inakatta Hanashi episode 1: https://ouo.io/Vy0yxQ

[ASW] Goukon ni Ittara Onna ga Inakatta Hanashi - 02 [1080p HEVC][53787C5A]: https://ouo.io/9geQmC

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 2: https://ouo.io/r8qZUPS

[ASW] Goukon ni Ittara Onna ga Inakatta Hanashi - 03 [1080p HEVC][46AF6A47]: https://ouo.io/kFcqCx

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 3: https://ouo.io/RValNXo

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 4: https://ouo.io/EyhZa7

[ASW] Goukon ni Ittara Onna ga Inakatta Hanashi - 04 [1080p HEVC][11545FEC]: https://ouo.io/frasD7

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 5: https://ouo.io/7J0HMo

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 6: https://ouo.io/3dpO5G

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 7: https://ouo.io/XVlJS3V

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 8: https://ouo.io/3yDuu2

Goukon ni Ittara Onna ga Inakatta Hanashi Episode 9: https://ouo.io/FUgvsBS

[SubsPlease] Goukon ni Ittara Onna ga Inakatta Hanashi - 10 (1080p) [D5602866]: https://ouo.io/pAbDrPg

[SubsPlease] Goukon ni Ittara Onna ga Inakatta Hanashi - 11 (1080p) [3C9D607E]: https://ouo.io/Dx8N1L

[SubsPlease] Goukon ni Ittara Onna ga Inakatta Hanashi - 12 (1080p) [773A5F7A]: https://ouo.io/6Asvykv

-----------------------------------------------------------------------------------------------------------------------------------------------------------
How I Attended an All-Guy's Mixer episode 1 eng dub: https://ouo.io/Phfo4m
How I Attended an All-Guy's Mixer episode 2 eng dub: https://ouo.io/4I8dOh
How I Attended an All-Guy's Mixer episode 3 eng dub: https://ouo.io/sKXB7p
How I Attended an All-Guy's Mixer episode 4 eng dub: https://ouo.io/KSw9u3
How I Attended an All-Guy's Mixer episode 5 eng dub: https://ouo.io/V3VFIu
How I Attended an All-Guy's Mixer episode 6 eng dub: https://ouo.io/lO4DTb
How I Attended an All-Guy's Mixer episode 7 eng dub: https://ouo.io/NxgFLSr
How I Attended an All-Guy's Mixer episode 8 eng dub: https://ouo.io/Xzh91H
How I Attended an All-Guy's Mixer episode 9 eng dub: https://ouo.io/1KJpTY
How I Attended an All-Guy's Mixer episode 10 eng dub: https://ouo.io/qOGGunr
How I Attended an All-Guy's Mixer episode 11 eng dub: https://ouo.io/fuYqzGq
How I Attended an All-Guy's Mixer episode 12 eng dub: https://ouo.io/ea1PxxH
------------------------------------------------------------------------------------------------------------------------------------------------------------------
chainsaw man eng sub

[Erai-raws] Chainsaw Man - 01 [480p][Multiple Subtitle][A295DF24]: https://ouo.io/cP1fHV
[Erai-raws] Chainsaw Man - 01 [720p][Multiple Subtitle][DA789291]: https://ouo.io/um2waH
[Erai-raws] Chainsaw Man - 01 [1080p][Multiple Subtitle][6F20C80A]: https://ouo.io/6sGMjs
[NC-Raws] Chainsaw Man - 01 (B-Global 3840x2160 HEVC AAC MKV) [870F976A]: https://ouo.io/Yx9TCa
[YuiSubs] Chainsaw Man - 01 (x265 H.265 1080p): https://ouo.io/ufRsOY
Chainsaw Man Episode 1: https://ouo.io/2DMq7C
[SubsPlease] Chainsaw Man - 01 (480p) [850CADE5]: https://ouo.io/1KuwPG
[SubsPlease] Chainsaw Man - 01 (720p) [88C94187]: https://ouo.io/NMtRkCO
[SubsPlease] Chainsaw Man - 01 (1080p) [FE86A50F]: https://ouo.io/2DtNUC
[sam] Chainsaw Man - 01 v2 [WEB 1080p EAC-3] [930A6FBE]: https://ouo.io/aZ0jrz
[Erai-raws] Chainsaw Man - 02 [480p][Multiple Subtitle][10EABB72]: https://ouo.io/KhTGRo
[Erai-raws] Chainsaw Man - 02 [720p][Multiple Subtitle][9613F438]: https://ouo.io/LdWSt6
[Erai-raws] Chainsaw Man - 02 [1080p][Multiple Subtitle][0F3B50C7]: https://ouo.io/RM0tSc
Chainsaw Man Episode 2: https://ouo.io/HOhlMQj
[YuiSubs] Chainsaw Man - 02 (x265 H.265 1080p): https://ouo.io/5oz5mK
[Anime Time] Chainsaw Man - 02 [1080p][HEVC 10bit x265][AAC][Multi Sub]: https://ouo.io/JvAwzP
[SubsPlease] Chainsaw Man - 02 (480p) [3D7FF3B0]: https://ouo.io/POqBvK
[SubsPlease] Chainsaw Man - 02 (720p) [8324378A]: https://ouo.io/keQvF2
[SubsPlease] Chainsaw Man - 02 (1080p) [CAEC8DA3]: https://ouo.io/FbSvqG
[sam] Chainsaw Man - 02v2 [WEB 1080p EAC-3] [F16F1915]: https://ouo.io/6vNV5d
[NC-Raws] 电锯人 - 03 (B-Global 3840x2160 HEVC AAC MKV) [59233F4F]: https://ouo.io/oul6vd
[Anime Time] Chainsaw Man - 03 [1080p][HEVC 10bit x265][AAC][Eng Sub]: https://ouo.io/6coNjdy
[ASW] Chainsaw Man - 03 [1080p HEVC][2C7A1B44]: https://ouo.io/Ounmejs
Chainsaw Man Episode 3: https://ouo.io/M1PH3Ga
[EMBER] Chainsaw Man - 03: https://ouo.io/XGLkBW
Chainsaw Man - S01E03 - MEOWY'S WHEREABOUTS: https://ouo.io/7fuOb0x
[YuiSubs] Chainsaw Man - 03 (x265 H.265 1080p): https://ouo.io/lJ8TpL3
[SubsPlease] Chainsaw Man - 03 (480p) [08FB4AD9]: https://ouo.io/LvJtwVo
[SubsPlease] Chainsaw Man - 03 (720p) [7C72C405]: https://ouo.io/tj3Je1


------------------------------------------------------------------------------------------------------------------------------------------------------------------------
next anime coming
chainsaw man sub will take sometime to get live
(  it will take about 3-5 days  )
one piece episode 1- 5 (  it will take about 3-5 days  )
chainsaw man eng dubbed (it might be avalible till next week)
`;

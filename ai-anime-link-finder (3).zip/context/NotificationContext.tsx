import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { MockEmail } from '../types';

interface NotificationContextType {
  emails: MockEmail[];
  unreadCount: number;
  sendMockEmail: (subject: string, body: string) => void;
  markEmailAsRead: (id: string) => void;
  clearEmails: () => void;
}

const NotificationContext = createContext<NotificationContextType>(null!);

const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [emails, setEmails] = useState<MockEmail[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    try {
      const storedEmails = localStorage.getItem('mockEmails');
      if (storedEmails) {
        const parsedEmails: MockEmail[] = JSON.parse(storedEmails);
        setEmails(parsedEmails);
        setUnreadCount(parsedEmails.filter(e => !e.read).length);
      }
    } catch (error) {
      console.error("Failed to parse emails from localStorage", error);
    }
  }, []);

  const saveEmails = (newEmails: MockEmail[]) => {
    localStorage.setItem('mockEmails', JSON.stringify(newEmails));
    setEmails(newEmails);
    setUnreadCount(newEmails.filter(e => !e.read).length);
  };

  const sendMockEmail = (subject: string, body: string) => {
    const newEmail: MockEmail = {
      id: Date.now().toString(),
      subject,
      body,
      timestamp: new Date().toISOString(),
      read: false,
    };
    const updatedEmails = [newEmail, ...emails];
    saveEmails(updatedEmails);
  };

  const markEmailAsRead = (id: string) => {
    const updatedEmails = emails.map(email =>
      email.id === id ? { ...email, read: true } : email
    );
    saveEmails(updatedEmails);
  };

  const clearEmails = () => {
    saveEmails([]);
  };

  const value = { emails, unreadCount, sendMockEmail, markEmailAsRead, clearEmails };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};

export { NotificationContext, NotificationProvider };

import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { AuthState } from '../types';

interface AuthContextType {
  authState: AuthState;
  signup: (userIdentifier: string, email: string, payeerWallet: string) => void;
  spendToken: () => void;
  addTokens: (amount: number) => void;
  claimDailyCredits: () => boolean;
  getLastClaimDate: () => string | null;
}

const AuthContext = createContext<AuthContextType>(null!);

const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [authState, setAuthState] = useState<AuthState>({
    isLoggedIn: false,
    tokens: 0,
    userIdentifier: null,
    email: null,
    payeerWallet: null,
  });

  // Load state from localStorage on initial render
  useEffect(() => {
    try {
      const storedState = localStorage.getItem('authState');
      if (storedState) {
        setAuthState(JSON.parse(storedState));
      }
    } catch (error) {
      console.error("Failed to parse auth state from localStorage", error);
    }
  }, []);
  
  const saveState = (newState: AuthState) => {
    localStorage.setItem('authState', JSON.stringify(newState));
    setAuthState(newState);
  };

  const signup = (userIdentifier: string, email: string, payeerWallet: string) => {
    const newState = { isLoggedIn: true, tokens: 0, userIdentifier, email, payeerWallet };
    saveState(newState);
    // Set daily claim date to yesterday to allow immediate first claim
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    localStorage.setItem('lastDailyClaim', yesterday.toDateString());
  };

  const spendToken = () => {
    setAuthState(prev => {
        const newTokens = Math.max(0, prev.tokens - 1);
        const newState = { ...prev, tokens: newTokens };
        saveState(newState);
        return newState;
    });
  };

  const addTokens = (amount: number) => {
    setAuthState(prev => {
        const newState = { ...prev, tokens: prev.tokens + amount };
        saveState(newState);
        return newState;
    });
  };
  
  const getLastClaimDate = () => localStorage.getItem('lastDailyClaim');

  const claimDailyCredits = (): boolean => {
    const today = new Date().toDateString();
    const lastClaimDate = getLastClaimDate();

    if (lastClaimDate === today) {
        return false; // Already claimed today
    }
    
    let claimed = false;
    setAuthState(prev => {
        if (prev.tokens < 5) {
            const tokensToAdd = 3;
            const newTotal = Math.min(prev.tokens + tokensToAdd, 5); // Cap at 5
            const newState = { ...prev, tokens: newTotal };
            saveState(newState);
            localStorage.setItem('lastDailyClaim', today);
            claimed = true;
            return newState;
        }
        return prev;
    });
    return claimed;
  };

  const value = { authState, signup, spendToken, addTokens, claimDailyCredits, getLastClaimDate };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export { AuthContext, AuthProvider };
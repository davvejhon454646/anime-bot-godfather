
import React from 'react';
import { TokenPackage } from '../types';

interface PaymentModalProps {
  onClose: () => void;
  onInitiatePurchase: (pkg: TokenPackage) => void;
}

const tokenPackages: TokenPackage[] = [
    { tokens: 500, price: 0.5, id: 'tier1' },
    { tokens: 2000, price: 1, id: 'tier2' },
    { tokens: 8000, price: 3, id: 'tier3' },
];

const PaymentModal: React.FC<PaymentModalProps> = ({ onClose, onInitiatePurchase }) => {

  const handleSelectPackage = (pkg: TokenPackage) => {
    onInitiatePurchase(pkg);
    onClose();
  };

  return (
    <div 
        className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60 modal-overlay"
        aria-modal="true"
        role="dialog"
    >
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-lg w-full mx-4 p-8 modal-content relative">
        <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"
            aria-label="Close modal"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>

        <h2 className="text-2xl sm:text-3xl font-extrabold text-center text-slate-900 dark:text-white">
            Get More <span className="text-orange-500">Tokens</span>
        </h2>
        <p className="mt-2 text-center text-slate-600 dark:text-slate-300">
            Choose a package to continue chatting. This is a monthly subscription.
        </p>

        <div className="mt-8 space-y-4">
            {tokenPackages.map(pkg => (
                <div key={pkg.id} className="border border-slate-200 dark:border-slate-700 rounded-lg p-4 flex items-center justify-between">
                    <div>
                        <p className="font-bold text-lg text-slate-800 dark:text-slate-100">{pkg.tokens.toLocaleString()} Tokens</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400">One-time purchase</p>
                    </div>
                    <button 
                        onClick={() => handleSelectPackage(pkg)}
                        className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-6 rounded-lg transition-colors"
                    >
                        ${pkg.price.toFixed(2)}
                    </button>
                </div>
            ))}
        </div>
        
        <div className="mt-6 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">
                This is a simulation. Clicking a purchase button will navigate to a mock checkout page for demonstration purposes.
            </p>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;

import React from 'react';
import { Message } from '../types';
import Loader from './Loader';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.sender === 'user';

  return (
    <div
      className={`flex items-start gap-3 animate-fade-in ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
    >
      <div
        className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center font-bold text-white ${isUser ? 'bg-orange-500' : 'bg-slate-600'}`}
      >
        {isUser ? 'U' : 'AI'}
      </div>
      <div
        className={`max-w-xl rounded-xl p-4 text-white ${isUser ? 'bg-orange-500' : 'bg-slate-700'}`}
        aria-live="polite"
      >
        {message.isLoading ? (
          <Loader />
        ) : (
          <p className="whitespace-pre-wrap">{message.text}</p>
        )}
        {message.links && message.links.length > 0 && (
          <div className="mt-4 border-t border-slate-500/50 pt-3 space-y-3">
            {message.links.map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block p-3 bg-slate-600 hover:bg-slate-500 rounded-lg transition-colors group"
              >
                <p className="font-semibold text-sm text-slate-200 group-hover:text-white truncate">
                  {link.text}
                </p>
                <p className="text-xs text-orange-300 group-hover:underline">
                  {link.url}
                </p>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;

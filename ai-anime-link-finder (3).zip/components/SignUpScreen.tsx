import React, { useContext, useState } from 'react';
import { AuthContext } from '../context/AuthContext';

const SignUpScreen: React.FC = () => {
  const { signup } = useContext(AuthContext);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [payeerWallet, setPayeerWallet] = useState('');
  const [error, setError] = useState('');

  const validateForm = () => {
    if (username.trim().length < 3) {
      setError('Username must be at least 3 characters long.');
      return false;
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
        setError('Please enter a valid email address.');
        return false;
    }
    if (!/^P\d{8,}$/.test(payeerWallet.trim())) {
        setError('Please enter a valid Payeer Wallet address (e.g., P12345678).');
        return false;
    }
    return true;
  }

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    setError('');
    signup(username.trim(), email.trim(), payeerWallet.trim());
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-100 dark:bg-slate-900 p-4">
      <div className="text-center p-8 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 animate-fade-in">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
          Create an Account
        </h1>
        <p className="mt-4 text-slate-600 dark:text-slate-300">
          Sign up to start. You'll begin with 0 tokens and can claim 3 free tokens daily.
        </p>
        <form onSubmit={handleSignUp} className="mt-8 w-full flex flex-col items-center gap-4">
            <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="w-full p-4 bg-slate-100 dark:bg-slate-700 rounded-lg border-2 border-slate-300 dark:border-slate-600 focus:border-orange-500 focus:ring-orange-500 transition"
                aria-label="Username"
            />
             <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="w-full p-4 bg-slate-100 dark:bg-slate-700 rounded-lg border-2 border-slate-300 dark:border-slate-600 focus:border-orange-500 focus:ring-orange-500 transition"
                aria-label="Email Address"
            />
             <input
                type="text"
                value={payeerWallet}
                onChange={(e) => setPayeerWallet(e.target.value)}
                placeholder="Payeer Wallet (e.g., P101234567)"
                className="w-full p-4 bg-slate-100 dark:bg-slate-700 rounded-lg border-2 border-slate-300 dark:border-slate-600 focus:border-orange-500 focus:ring-orange-500 transition"
                aria-label="Payeer Wallet"
            />
            {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            <button
              type="submit"
              className="mt-4 w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 px-8 rounded-lg transition-transform transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-orange-300"
            >
              Sign Up & Continue
            </button>
        </form>
         <div className="mt-4 text-sm text-slate-500 dark:text-slate-400">
            Don't have a Payeer account?{' '}
            <a href="https://payeer.com/en/auth/?register=yes" target="_blank" rel="noopener noreferrer" className="text-orange-500 hover:underline font-semibold">
                Create one here.
            </a>
        </div>
      </div>
    </div>
  );
};

export default SignUpScreen;
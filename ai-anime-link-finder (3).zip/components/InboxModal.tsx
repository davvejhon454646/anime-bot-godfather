import React, { useContext, useState } from 'react';
import { NotificationContext } from '../context/NotificationContext';
import { MockEmail } from '../types';

interface InboxModalProps {
  onClose: () => void;
}

const InboxModal: React.FC<InboxModalProps> = ({ onClose }) => {
  const { emails, markEmailAsRead, clearEmails } = useContext(NotificationContext);
  const [selectedEmail, setSelectedEmail] = useState<MockEmail | null>(null);

  const handleSelectEmail = (email: MockEmail) => {
    setSelectedEmail(email);
    if (!email.read) {
      markEmailAsRead(email.id);
    }
  };

  const timeSince = (date: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " years ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " months ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " days ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " hours ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " minutes ago";
    return Math.floor(seconds) + " seconds ago";
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60 modal-overlay" aria-modal="true" role="dialog">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-2xl w-full mx-4 h-full max-h-[80vh] flex flex-col modal-content relative">
        <header className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">Inbox</h2>
            <div className="flex items-center gap-2">
                 <button onClick={clearEmails} className="text-xs text-slate-500 hover:text-red-500 hover:underline disabled:opacity-50" disabled={emails.length === 0}>
                    Clear All
                </button>
                <button onClick={onClose} className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition" aria-label="Close modal">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
        </header>

        <div className="flex-1 flex overflow-hidden">
            {/* Email List */}
            <div className={`w-full md:w-2/5 border-r border-slate-200 dark:border-slate-700 overflow-y-auto chat-scrollbar ${selectedEmail ? 'hidden md:block' : 'block'}`}>
                {emails.length > 0 ? (
                    <ul>
                        {emails.map(email => (
                            <li key={email.id}>
                                <button onClick={() => handleSelectEmail(email)} className="w-full text-left p-4 hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-colors border-b border-slate-200 dark:border-slate-700/50">
                                    <div className="flex justify-between items-start">
                                        <p className={`font-bold truncate ${!email.read ? 'text-slate-800 dark:text-slate-100' : 'text-slate-500 dark:text-slate-400'}`}>{email.subject}</p>
                                        {!email.read && <div className="w-2.5 h-2.5 bg-orange-500 rounded-full flex-shrink-0 ml-2 mt-1.5"></div>}
                                    </div>
                                    <p className="text-xs text-slate-400 dark:text-slate-500">{timeSince(email.timestamp)}</p>
                                </button>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="p-8 text-center text-slate-500">
                        <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                        <p className="mt-4 font-semibold">Your inbox is empty.</p>
                        <p className="text-sm">Payment notifications will appear here.</p>
                    </div>
                )}
            </div>

            {/* Email Content */}
            <div className={`flex-1 overflow-y-auto p-6 ${selectedEmail ? 'block' : 'hidden md:block'}`}>
                {selectedEmail ? (
                    <div>
                        {selectedEmail && (
                            <button onClick={() => setSelectedEmail(null)} className="md:hidden mb-4 text-sm text-orange-500 hover:underline">
                                &larr; Back to Inbox
                            </button>
                        )}
                        <h3 className="text-2xl font-bold mb-2 text-slate-900 dark:text-white">{selectedEmail.subject}</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 border-b border-slate-200 dark:border-slate-700 pb-4">
                            To: You &lt;{'{your_email}'}&gt;<br/>
                            Date: {new Date(selectedEmail.timestamp).toLocaleString()}
                        </p>
                        <p className="whitespace-pre-wrap text-slate-700 dark:text-slate-300">
                            {selectedEmail.body}
                        </p>
                    </div>
                ) : (
                     <div className="h-full flex items-center justify-center text-center text-slate-500">
                        <div>
                            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                            <p className="mt-4 font-semibold">Select a message</p>
                            <p className="text-sm">Choose an email from the list to read its content.</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default InboxModal;

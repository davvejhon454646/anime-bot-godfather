
import React, { useState, useEffect, useContext } from 'react';
import { TokenPackage, MockTransaction } from '../types';
import { verifyPayeerTransaction, findTransaction, getValidTransactionExamples } from '../server/mockApi';
import { NotificationContext } from '../context/NotificationContext';

interface PaymentPageProps {
  pkg: TokenPackage;
  userIdentifier: string;
  userEmail: string;
  onPaymentSuccess: (tokens: number) => void;
  onCancel: () => void;
}

type VerificationStep = 'idle' | 'finding' | 'verifying' | 'error' | 'success';
const PAYEER_ACCOUNT = 'P1089247161';

const PaymentPage: React.FC<PaymentPageProps> = ({ pkg, userIdentifier, userEmail, onPaymentSuccess, onCancel }) => {
  const { sendMockEmail } = useContext(NotificationContext);
  const [transactionId, setTransactionId] = useState('');
  const [step, setStep] = useState<VerificationStep>('idle');
  const [message, setMessage] = useState('');
  const [progress, setProgress] = useState(0);
  const [examples, setExamples] = useState<MockTransaction[]>([]);

  useEffect(() => {
    setExamples(getValidTransactionExamples());
  }, []);

  const handleVerify = async () => {
    if (!transactionId.trim()) {
      setMessage('Please enter a transaction ID.');
      setStep('error');
      return;
    }
    
    // Start Verification Process
    setMessage('Searching for your transaction in the network...');
    setStep('finding');
    setProgress(25);

    const foundTx = await findTransaction(transactionId);
    
    if (!foundTx) {
      setProgress(100);
      setStep('error');
      const errorMessage = `Transaction ID '${transactionId}' was not found in our system. Please double-check the ID. If you have already paid, contact support.`;
      setMessage(errorMessage);
      sendMockEmail("Payment Verification Failed", `Hello ${userIdentifier},\n\nWe could not find a payment associated with the Transaction ID you provided: ${transactionId}.\n\nPlease ensure the ID is correct and that you included your username in the memo.\n\n- The AI Team`);
      return;
    }

    setProgress(50);
    setMessage(`Found payment of $${foundTx.amount.toFixed(2)}. Verifying details...`);
    setStep('verifying');

    const result = await verifyPayeerTransaction(transactionId, userIdentifier, pkg.price);

    setProgress(100);
    if (result.success) {
      setStep('success');
      setMessage(`Success! Tokens granted. A confirmation email has been sent.`);
      sendMockEmail("Payment Successful!", `Hello ${userIdentifier},\n\nYour payment of $${pkg.price.toFixed(2)} for ${pkg.tokens.toLocaleString()} tokens has been successfully verified (TID: ${transactionId}).\n\nThe tokens have been added to your account.\n\nThank you!\n- The AI Team`);
      setTimeout(() => {
        onPaymentSuccess(pkg.tokens);
      }, 1500);
    } else {
      setStep('error');
      setMessage(result.message);
      sendMockEmail("Payment Verification Failed", `Hello ${userIdentifier},\n\nThere was an issue verifying your payment for $${pkg.price.toFixed(2)} with Transaction ID ${transactionId}.\n\nReason: ${result.message}\n\nPlease review the details and try again, or contact support if you believe this is an error.\n\n- The AI Team`);
    }
  };

  const isProcessing = step === 'finding' || step === 'verifying' || step === 'success';
  const relevantExample = examples.find(ex => ex.amount === pkg.price && !ex.claimed);

  return (
    <div className="absolute inset-0 bg-slate-100 dark:bg-slate-900 flex items-center justify-center animate-page-slide-in z-20 p-4">
      <div className="w-full max-w-2xl mx-auto bg-white dark:bg-slate-800 rounded-2xl shadow-2xl p-8 overflow-y-auto max-h-full">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Final Step: Manual Payment</h1>
          <p className="mt-2 text-slate-500 dark:text-slate-400">Please follow the instructions below.</p>
        </div>

        <div className="mt-6 p-4 bg-yellow-100 dark:bg-yellow-900/50 rounded-lg text-yellow-800 dark:text-yellow-300">
            <p className="font-bold text-center">SIMULATION INSTRUCTIONS</p>
            {relevantExample ? (
                 <div className="mt-2 text-sm">
                    <p>To test a successful payment for <strong className="font-semibold">${pkg.price.toFixed(2)}</strong>, log in with username <strong className="font-semibold">{relevantExample.userIdentifier}</strong> and use this ID:</p>
                    <div className="mt-1 p-2 bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-md text-center font-mono break-all cursor-pointer" onClick={() => {setTransactionId(relevantExample.transactionId); navigator.clipboard.writeText(relevantExample.transactionId)}}>
                        {relevantExample.transactionId} (Click to copy & use)
                    </div>
                </div>
            ) : (
                <p className="text-sm mt-2 text-center font-semibold">No valid example transaction found for this amount.</p>
            )}
        </div>

        <div className="mt-6 space-y-6 text-sm">
            {/* Steps 1 & 2 */}
             <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-orange-500 text-white font-bold rounded-full flex items-center justify-center">1</div>
                <div className="pt-1 w-full">
                    <h3 className="font-bold text-slate-800 dark:text-slate-100">Send Payment & Include Memo</h3>
                    <p className="text-slate-600 dark:text-slate-300">
                        Send <strong className="text-orange-500">${pkg.price.toFixed(2)} USD</strong> to <strong className="font-mono">{PAYEER_ACCOUNT}</strong>.
                    </p>
                     <p className="text-slate-600 dark:text-slate-300 mt-1">
                       You <strong className="text-red-500">MUST</strong> include your username <strong className="font-mono">{userIdentifier}</strong> in the payment's memo/comment.
                    </p>
                </div>
            </div>

            {/* Step 3: Verify */}
            <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-orange-500 text-white font-bold rounded-full flex items-center justify-center">2</div>
                <div className="pt-1 w-full">
                    <h3 className="font-bold text-slate-800 dark:text-slate-100">Verify Your Payment</h3>
                    <p className="text-slate-600 dark:text-slate-300">
                        After sending, paste the Transaction ID from Payeer below. A confirmation email will be sent to <strong className="font-semibold">{userEmail}</strong>.
                    </p>
                    <input
                        type="text"
                        value={transactionId}
                        onChange={(e) => setTransactionId(e.target.value)}
                        placeholder="Paste Transaction ID here"
                        disabled={isProcessing}
                        className="mt-2 w-full p-3 bg-slate-100 dark:bg-slate-700 rounded-lg border-2 border-slate-300 dark:border-slate-600 focus:border-orange-500 focus:ring-orange-500 transition disabled:opacity-50"
                    />
                </div>
            </div>
        </div>

        <div className="mt-8">
          {!isProcessing ? (
             <button
              onClick={handleVerify}
              disabled={!transactionId.trim()}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 px-8 rounded-lg transition-transform transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-orange-300 disabled:bg-slate-400 disabled:cursor-not-allowed"
            >
              Verify Payment
            </button>
          ) : (
            <div className="text-center animate-fade-in space-y-3">
                 <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
                    <div 
                        className="h-2.5 rounded-full transition-all duration-500 ease-out bg-green-500"
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
                <p className="text-lg font-semibold text-slate-600 dark:text-slate-300">
                    {message}
                </p>
            </div>
          )}
           {step === 'error' && message && !isProcessing && <p className="text-red-500 text-sm mt-2 text-center animate-fade-in">{message}</p>}
        </div>

        <div className="mt-4 text-center">
          <button
            onClick={onCancel}
            disabled={isProcessing}
            className="text-sm text-slate-500 hover:underline disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Cancel and return to chat
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;